# ShutterHunters — publishable public preview

This is a **static interactive demonstration** of ShutterHunters. It can be hosted free on GitHub Pages. It does not create real accounts, connect users nationwide, process payments, or verify reviews. Demo data stays in the visitor's browser.

## Publish with GitHub Pages (desktop)

1. Sign in to https://github.com/new and create a **public** repository named `shutterhunters-preview`.
2. Select **Add file → Upload files**, upload `index.html` from this folder, and commit.
3. Go to **Settings → Pages → Build and deployment**, select **Deploy from a branch**, `main`, `/ (root)`, and Save.
4. Wait for GitHub to publish. The expected URL format is `https://YOUR-USERNAME.github.io/shutterhunters-preview/` (replace YOUR-USERNAME). Confirm the actual URL on the Pages settings screen.

## Production MVP

The separate `shutterhunters-nationwide-mvp-v03.zip` contains a Python/SQLite prototype for registration, profiles, jobs and applications. **Do not deploy it publicly as-is.** It requires security hardening, a managed database, moderation, verification, legal documents, backups, and deployment configuration. Payment processing is not implemented.
